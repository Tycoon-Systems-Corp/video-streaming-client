import React from"react";const LANGUAGE_OPTIONS=[{key:"javascript",label:"Javascript"},{key:"python",label:"Python"},{key:"cpp",label:"C++"}],resolveCodeSample=({language:e,endpoint:a,domainKey:t,feedId:l,apiKey:o})=>{t=t||"YOUR_DOMAIN_KEY",l=l||"YOUR_FEED_ID",o=o||"YOUR_API_KEY";return"python"===e?`import requests

url = "${a}"
payload = {
    "domainKey": "${t}",
    "feed": "${l}",
    "apiKey": "${o}",
    "object": {
        "type": "price",
        "value": 123.45,
        "description": "Price update"
    }
}

res = requests.post(url, json=payload, timeout=10)
print(res.status_code)
print(res.json())`:"cpp"===e?`#include <curl/curl.h>
#include <iostream>
#include <string>

int main() {
    CURL* curl = curl_easy_init();
    if (!curl) return 1;

    std::string payload = R"({
  "domainKey": "${t}",
  "feed": "${l}",
  "apiKey": "${o}",
  "object": {
    "type": "price",
    "value": 123.45,
    "description": "Price update"
  }
})";

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");

    curl_easy_setopt(curl, CURLOPT_URL, "${a}");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, payload.c_str());

    CURLcode result = curl_easy_perform(curl);
    if (result != CURLE_OK) {
        std::cerr << "curl error: " << curl_easy_strerror(result) << std::endl;
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    return 0;
}`:`const endpoint = "${a}"

const payload = {
    domainKey: "${t}",
    feed: "${l}",
    apiKey: "${o}",
    object: {
        type: "price",
        value: 123.45,
        description: "Price update"
    }
}

const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
})

const data = await res.json()
console.log(data)`},Module=e=>{const[a,t]=React.useState("javascript"),[l,o]=React.useState(!1);React.useEffect(()=>{e?.visible&&(t("javascript"),o(!1))},[e?.visible]),React.useEffect(()=>{o(!1)},[a]);var r=React.useCallback(async()=>{if(n)try{await navigator.clipboard.writeText(n),o(!0),setTimeout(()=>{o(!1)},1400)}catch(e){o(!1)}},[n]);if(!e?.visible)return null;var c=e?.apiUrl?e.apiUrl+"/appendfeedrss":"https://YOUR_API_URL/appendfeedrss";const n=resolveCodeSample({language:a,endpoint:c,domainKey:e?.domainKey,feedId:e?.feedId,apiKey:e?.apiKey});return React.createElement("div",{className:"ProfilePage_CodeModalOverlay",onClick:e?.onClose},React.createElement("div",{className:"ProfilePage_CodeModal",onClick:e=>e.stopPropagation()},React.createElement("div",{className:"ProfilePage_CodeModalHeader"},React.createElement("h4",{style:{margin:0}},"Append Feed RSS"),React.createElement("button",{type:"button",className:"simpleButton ProfilePage_CodeModalCloseButton",onClick:e?.onClose},"Close")),React.createElement("div",{className:"ProfilePage_CodeModalLead"},"Send a POST request to append a new item into this feed."),React.createElement("div",{className:"ProfilePage_CodeModalTabs"},LANGUAGE_OPTIONS.map(e=>React.createElement("button",{key:e.key,type:"button",className:"ProfilePage_CodeModalTabButton pointer "+(a===e.key?"ProfilePage_CodeModalTabButtonActive":""),onClick:()=>t(e.key)},e.label))),React.createElement("div",{className:"ProfilePage_CodeModalDoc"},React.createElement("div",null,React.createElement("strong",null,"Endpoint:")," ",c),React.createElement("div",null,React.createElement("strong",null,"Required body:")," domainKey, feed, apiKey, object"),React.createElement("div",{className:"ProfilePage_CodeModalCodePreWrap"},React.createElement("button",{type:"button",className:"ProfilePage_CodeModalCopyButton",onClick:r},l?"Copied":"Copy"),React.createElement("pre",{className:"ProfilePage_CodeModalCodePre"},React.createElement("code",null,n))))))};export default Module;