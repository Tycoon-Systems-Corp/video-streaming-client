import React from 'react'
import { useRouter } from 'next/router'
import { AdminPanel, BeginStream, UsernameContainer, UserFeed, UserIcon, UserShop, Follow, Message } from '@tycoonsystems/tycoon-modules/profile'
import { selectThisText } from '@tycoonsystems/tycoon-modules/utility/utility/event'
import { IndexHello } from '@tycoonsystems/tycoon-modules/presentation/hello/IndexHello'
import { FeedManager } from '@tycoonsystems/tycoon-modules/ecommerce/feed'

const Module = props => {
    const router = useRouter()
    const [ activeTab, setActiveTab ] = React.useState('videos')

    const adminAuth = props?.adminAuth
    const hasVideos = props?.videoData?.videos && props.videoData.videos.length > 0

    const handleUploadVideo = React.useCallback(() => {
        router.push('/upload')
    }, [ router ])

    return (
        <div>
            <AdminPanel { ...props } />
            {
                props?.profileData?.user
                    ? <div>
                        <div className={`${props?.className ?? ''} flex wrap gap-p10 PagePadding pTop ProfilePage_ProfileContainer`}>
                            <UserIcon { ...props } />
                            <div>
                                <div className={`flex wrap gap-p5 al-cen`} style={{ height: 'fit-content' }}>
                                    <UsernameContainer { ...props } />
                                    <BeginStream { ...props } />
                                </div>
                                <div className={`flex wrap gap-p5 al-cen selectThisText`} style={{ height: 'fit-content', marginTop: '.5rem' }}>
                                    <button className='flex gap-p2' style={{ borderRadius: '1rem', alignItems: 'normal' }} selectValue={`https://${props?.domainUrl ?? ''}/p?u=${props?.profileData?.user?.id}`} onClick={selectThisText}>
                                        <div className={`material-icons Profile_share_profile`} style={{ fontSize: '14px' }}>ios_share</div>
                                        <div>Share</div>
                                    </button>
                                    <Follow { ...props } />
                                    <Message { ...props } />
                                </div>
                            </div>
                        </div>
                        <UserFeed { ...props } />
                        <div className='PagePadding' style={{ paddingTop: '.5rem', paddingBottom: '.5rem' }}>
                            <div className='flex wrap gap-p10' role='tablist' aria-label='Profile sections' style={{ borderBottom: '1px solid #2f2f2f' }}>
                                <button
                                    role='tab'
                                    aria-selected={activeTab === 'videos'}
                                    type='button'
                                    onClick={() => setActiveTab('videos')}
                                    className={`ProfilePage_TabButton ${activeTab === 'videos' ? 'ProfilePage_TabButtonActive' : ''}`}
                                >
                                    Videos
                                </button>
                                <button
                                    role='tab'
                                    aria-selected={activeTab === 'shop'}
                                    type='button'
                                    onClick={() => setActiveTab('shop')}
                                    className={`ProfilePage_TabButton ${activeTab === 'shop' ? 'ProfilePage_TabButtonActive' : ''}`}
                                >
                                    Shop
                                </button>
                                <button
                                    role='tab'
                                    aria-selected={activeTab === 'feed'}
                                    type='button'
                                    onClick={() => setActiveTab('feed')}
                                    className={`ProfilePage_TabButton ${activeTab === 'feed' ? 'ProfilePage_TabButtonActive' : ''}`}
                                >
                                    Feed
                                </button>
                            </div>
                        </div>
                        {
                            activeTab === 'videos'
                                ? <div className='ProfilePage_Feed' role='tabpanel' aria-label='Videos'>
                                    {
                                        adminAuth && !hasVideos
                                            ? <div className='PagePadding' style={{ marginBottom: '1rem' }}>
                                                <button onClick={handleUploadVideo} style={{ borderRadius: '1rem' }}>Upload Video</button>
                                                <div style={{ fontSize: '.85rem', color: '#b0b0b0', marginTop: '.5rem' }}>You don't have any videos yet. Upload your first video to get started.</div>
                                            </div>
                                            : null
                                    }
                                    <IndexHello { ...props } groupLabel={'Most Recent'} items={props?.videoData?.videos ?? []} />
                                </div>
                                : activeTab === 'shop'
                                    ? <div role='tabpanel' aria-label='Shop'>
                                        <UserShop { ...props } />
                                    </div>
                                    : <div role='tabpanel' aria-label='Feed'>
                                        <FeedManager { ...props } />
                                    </div>
                        }
                    </div>
                    : null
            }
        </div>
    )
}

export default Module
