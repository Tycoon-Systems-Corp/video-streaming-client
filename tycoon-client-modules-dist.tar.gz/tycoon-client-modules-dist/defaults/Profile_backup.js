import React from 'react'
import { AdminPanel, BeginStream, UsernameContainer, UserFeed, UserIcon, UserShop, Follow, Message } from '@tycoonsystems/tycoon-modules/profile'
import { selectThisText } from '@tycoonsystems/tycoon-modules/utility/utility/event'
import { IndexHello } from '@tycoonsystems/tycoon-modules/presentation/hello/IndexHello'

const Module = props => {
    return (
        <div>
            <AdminPanel { ...props } />
            {
                props?.profileData?.user
                    ? <div>
                        <div className={`${props?.className ?? ''} flex wrap gap-p10 PagePadding pTop ProfilePage_ProfileContainer`}>
                            <UserIcon { ...props } />
                            <div>
                                <div className={`flex wrap gap-p5 al-cen`} style={{ height: 'fit-content' }}>
                                    <UsernameContainer { ...props } />
                                    <BeginStream { ...props } />
                                </div>
                                <div className={`flex wrap gap-p5 al-cen selectThisText`} style={{ height: 'fit-content', marginTop: '.5rem' }}>
                                    <button className='flex gap-p2' style={{ borderRadius: '1rem', alignItems: 'normal' }} selectValue={`https://${props?.domainUrl ?? ''}/p?u=${props?.profileData?.user?.id}`} onClick={selectThisText}>
                                        <div className={`material-icons Profile_share_profile`} style={{ fontSize: '14px' }}>ios_share</div>
                                        <div>Share</div>
                                    </button>
                                    <Follow { ...props } />
                                    <Message { ...props } />
                                </div>
                            </div>
                        </div>
                        <UserFeed { ...props } />
                        <h3 style={{ padding: '0 1rem' }}>Videos</h3>
                        <div className='ProfilePage_Feed'>
                            <IndexHello { ...props } groupLabel={'Most Recent'} items={props?.videoData?.videos ?? []} />
                        </div>
                        <UserShop { ...props } />
                    </div>
                    : null
            }
        </div>
    )
}

export default Module
