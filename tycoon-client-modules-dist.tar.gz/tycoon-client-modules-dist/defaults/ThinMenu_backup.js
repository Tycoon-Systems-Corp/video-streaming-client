import React from "react";
import ThinMenuInternal from "@tycoonsystems/tycoon-modules/menu/ThinMenu/ThinMenuInternal"
import {
  Card,
  LinksOnly,
  LinksWithTitle,
  Socials,
  SocialLinks
} from "@tycoonsystems/tycoon-modules/menu/ThinMenu/ThinMenuInternal"
import styles from "@tycoonsystems/tycoon-modules/menu/ThinMenu/ThinMenu.module.scss"
import { getUserCountry } from "@tycoonsystems/tycoon-modules/utility/utility/geo"


const Module = (props) => {
  const { menuRef, isOpen, toggleMenu, closeMenu } = props;

  const cardComponents = [
    <Card
      // title="Tycoon"
      titleElement={<h3 style={{ color: "white" }}>Yapper</h3>}
      content="Delivering media and news for the next generation, hosting the forum for subject matter other players have long been too timid to address. Yapper delivers insights and perspectives about the ever-changing world for the obsessive viewer"
    />,
    <Card
      // title="Tycoon"
      titleElement={<h3 style={{ color: "white" }}>Television</h3>}
      content="Hosting 24/7 live broadcasting and on-demand video on a myriad of topics for young adults curious about the real stories other platforms are too afraid to tell them"
    />,
  ];

  const linkswithtitle = [
    <LinksWithTitle
      title="Communications"
      links={[{ text: "How we Tell Stories", href: "#" }, { text: "News Tips", href: "#" }]}
    />,
  ];

  const socials = [
    <Socials
      title="Follow"
      // label= "Facebook"
      // logo="/img/default/facebook-logo.png" 
      links= {[
        <SocialLinks
         label= "Facebook"
      logo="/img/default/facebook-logo.png"
        />, 
        <SocialLinks
         label= "Instagram"
      logo="/img/default/instagram.png"
        />,
      ]}
     />
  ]

  const CardsComponent = (<div className={styles.thinMenu__card}>
    {cardComponents.map((CardComponent, index) => (
      <React.Fragment key={index}>{CardComponent}</React.Fragment>
    ))}
    {/* <Card /> */}
  </div>)

  const links = [
    { text: "Livestreaming", href: "#" },
    { text: "Viral Moments", href: "#" },
    { text: "Journalism", href: "#" }
  ];

  const productlinks = [
    { text: "About Us", href: "#about" },
    { text: "Careers", href: "#careers" },
    { text: "Tech at Yapper", href: "#tech" },
    { text: "Tycoon Systems Corp.", href: "https://www.tycoon.systems" },
    { text: "Tycoon Production Studios", href: "#tycoonstudiostoronto" },
    { text: "Licensing", href: "#licensing" },
  ];

  const medialinks = [
    { text: "Watch", href: "#watchnow" },
    { text: "Insights", href: "#about" },
    { text: "Discussion", href: "#careers" },
    { text: "News", href: "#tech" },
  ];

  const MenuComponent = (<div className={styles.thinMenu__sectionContainer}>
    <div className={styles.thinMenu__header}>
      <h3>Platform</h3>
    </div>
    <div className={styles.thinMenu__containercontent}>
      {/* <LinksOnly /> */}

      {links && links.length > 0 && (
        <LinksOnly
          links={links}
          className={styles.firstcolumnlinks}
        />
      )}
      {/* <LinksWithTitle /> */}
      {linkswithtitle.map((Component, index) => (
        <React.Fragment key={index}>{Component}</React.Fragment>
      ))}
      {/* <Socials /> */}
      {socials.map((Component, index) => (
        <React.Fragment key={index}>{Component}</React.Fragment>
      ))}
    </div>
  </div>)

  const MenuComponent2 = (<div className={styles.thinMenu__sectionContainer}>
    <div className={styles.thinMenu__header}>
      <h3>Media</h3>
    </div>
    {medialinks && medialinks.length > 0 && (
      <LinksOnly
        links={medialinks}
        className={styles.thirdcolumnlinks}
      />
    )}
  </div>)

  const MenuComponent3 = (<div className={styles.thinMenu__sectionContainer}>
    <div className={styles.thinMenu__header}>
      <h3>Business</h3>
    </div>
    {productlinks && productlinks.length > 0 && (
      <LinksOnly
        links={productlinks}
        className={styles.secondcolumnlinks}
      />
    )}
  </div>)

  const items = [
    {
      text: 'Yapper TV & Its Products',
      short: 'Yapper TV',
      component: <React.Fragment>
        {CardsComponent}
        {MenuComponent}
        {MenuComponent2}
        {MenuComponent3}
      </React.Fragment>
    },
    {
      text: "New Programming",
      short: 'Programming',
      component: <React.Fragment>
      {CardsComponent}
      {MenuComponent3}
      {CardsComponent}
    </React.Fragment>
    },
    {
      text: "Livestreaming",
      short: 'Live',
      href: "#",
    },
    {
      text: "Subscribe",
      short: 'Sub',
      href: "#",
    },
    {
      text: "Customer Support",
      short: 'Support',
      href: "#",
    },
  ]

  const itemsRight = getUserCountry(props?._loggedIn?.meta, props?.regionsData) ? [
    {
      text: `${getUserCountry(props?._loggedIn?.meta, props?.regionsData)} Edition`,
      label: true
    }
  ] : []

  return (
    <>
      <ThinMenuInternal
        items={items}
        itemsRight={itemsRight}
        useHeight={'70vh'}
        useMarginTop={'2rem'}
        hideClose={false}
      />
    </>
  );
};

export default Module;
